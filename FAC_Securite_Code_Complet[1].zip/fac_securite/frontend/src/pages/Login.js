import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

const QUICK_ROLES = [
  { role:"GAP",email:"admin@fac.ci",pass:"admin123",label:"Directeur GAP"},
  { role:"RH", email:"rh@fac.ci",  pass:"rh123",   label:"Resp. RH"},
  { role:"OPS",email:"ops@fac.ci", pass:"ops123",   label:"Superviseur"},
];

export default function Login() {
  const [email, setEmail] = useState("admin@fac.ci");
  const [password, setPassword] = useState("admin123");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const nav = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true); setError("");
    try { await login(email, password); nav("/dashboard"); }
    catch(err) { setError(err.message || "Identifiants invalides"); }
    finally { setLoading(false); }
  };

  return (
    <div style={{minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:"#F5F7FA",fontFamily:"Arial,sans-serif"}}>
      <div style={{background:"#fff",border:"1px solid #E0DDD5",borderRadius:12,padding:40,width:380}}>
        <div style={{textAlign:"center",marginBottom:28}}>
          <div style={{width:48,height:48,background:"#1B2D5B",borderRadius:10,margin:"0 auto 12px",display:"flex",alignItems:"center",justifyContent:"center",fontSize:24}}>🛡</div>
          <div style={{fontSize:20,fontWeight:600,color:"#1B2D5B"}}>FAC Sécurité</div>
          <div style={{fontSize:13,color:"#C9A84C",marginTop:4}}>Système de gestion intégré</div>
        </div>
        {error && <div style={{background:"#FCEBEB",color:"#791F1F",padding:"8px 12px",borderRadius:8,fontSize:13,marginBottom:14}}>{error}</div>}
        <form onSubmit={handleLogin}>
          <div style={{marginBottom:12}}>
            <label style={{display:"block",fontSize:12,color:"#666",marginBottom:4,fontWeight:500}}>Email</label>
            <input value={email} onChange={e=>setEmail(e.target.value)} type="email" required style={{width:"100%",padding:"8px 10px",border:"1px solid #ccc",borderRadius:6,fontSize:13,boxSizing:"border-box"}} />
          </div>
          <div style={{marginBottom:16}}>
            <label style={{display:"block",fontSize:12,color:"#666",marginBottom:4,fontWeight:500}}>Mot de passe</label>
            <input value={password} onChange={e=>setPassword(e.target.value)} type="password" required style={{width:"100%",padding:"8px 10px",border:"1px solid #ccc",borderRadius:6,fontSize:13,boxSizing:"border-box"}} />
          </div>
          <div style={{marginBottom:12,fontSize:12,color:"#888"}}>Connexion rapide :</div>
          <div style={{display:"flex",gap:6,marginBottom:16}}>
            {QUICK_ROLES.map(r=>(
              <button key={r.role} type="button" onClick={()=>{setEmail(r.email);setPassword(r.pass);}}
                style={{flex:1,padding:"6px 4px",border:"1px solid #ccc",borderRadius:6,fontSize:11,cursor:"pointer",background:email===r.email?"#E6EBF5":"#fff",color:email===r.email?"#1B2D5B":"#555"}}>
                {r.label}
              </button>
            ))}
          </div>
          <button type="submit" disabled={loading}
            style={{width:"100%",padding:10,background:"#1B2D5B",color:"#fff",border:"none",borderRadius:8,fontSize:14,fontWeight:600,cursor:"pointer"}}>
            {loading ? "Connexion..." : "Se connecter"}
          </button>
        </form>
      </div>
    </div>
  );
}