import React, { useState, useEffect, useCallback } from "react";
import { api } from "../utils/api";

export default function Agents() {
  const [agents, setAgents] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterStatut, setFilterStatut] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editAgent, setEditAgent] = useState(null);
  const [form, setForm] = useState({matricule:"",nom:"",telephone:"",poste:"Garde statique",type_contrat:"CDI",vacation:"Jour",niveau:"Agent de sécurité",agrement:"",statut:"Actif",observations:""});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");

  const showToast = (msg) => { setToast(msg); setTimeout(()=>setToast(""), 3000); };

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const p = {};
      if (search) p.q = search;
      if (filterStatut) p.statut = filterStatut;
      const data = await api.getAgents(p);
      setAgents(data.data); setTotal(data.total);
    } catch(e) { setError(e.message); }
    finally { setLoading(false); }
  }, [search, filterStatut]);

  useEffect(() => { load(); }, [load]);

  const openNew = () => { setEditAgent(null); setForm({matricule:"",nom:"",telephone:"",poste:"Garde statique",type_contrat:"CDI",vacation:"Jour",niveau:"Agent de sécurité",agrement:"",statut:"Actif",observations:""}); setShowModal(true); };
  const openEdit = (a) => { setEditAgent(a); setForm({...a}); setShowModal(true); };
  const handleSave = async () => {
    setSaving(true);
    try {
      if (editAgent) { await api.updateAgent(editAgent.id, form); showToast("Agent mis à jour"); }
      else { await api.createAgent(form); showToast("Agent créé"); }
      setShowModal(false); load();
    } catch(e) { setError(e.message); }
    finally { setSaving(false); }
  };
  const handleDelete = async (id) => {
    if (!window.confirm("Supprimer cet agent ?")) return;
    await api.deleteAgent(id); showToast("Agent supprimé"); load();
  };

  const statutColor = { Actif:"#27500A", Inactif:"#5F5E5A", Suspendu:"#791F1F", "En congé":"#633806" };
  const statutBg = { Actif:"#EAF3DE", Inactif:"#F1EFE8", Suspendu:"#FCEBEB", "En congé":"#FAEEDA" };

  return (
    <div style={{padding:24,fontFamily:"Arial,sans-serif"}}>
      {toast && <div style={{position:"fixed",top:16,right:16,background:"#1B2D5B",color:"#fff",padding:"10px 18px",borderRadius:8,zIndex:999,fontSize:13}}>{toast}</div>}
      <div style={{display:"flex",gap:12,marginBottom:16,alignItems:"center",flexWrap:"wrap"}}>
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Rechercher un agent…" style={{flex:1,maxWidth:280,padding:"7px 10px",border:"1px solid #ccc",borderRadius:6,fontSize:13}} />
        <select value={filterStatut} onChange={e=>setFilterStatut(e.target.value)} style={{padding:"7px 10px",border:"1px solid #ccc",borderRadius:6,fontSize:13}}>
          <option value="">Tous statuts</option><option>Actif</option><option>Inactif</option><option>Suspendu</option>
        </select>
        <button onClick={openNew} style={{padding:"7px 16px",background:"#1B2D5B",color:"#fff",border:"none",borderRadius:6,fontSize:13,cursor:"pointer"}}>+ Nouvel agent</button>
        <button onClick={()=>api.getAgents().then(d=>{ const csv="Matricule,Nom,Site,Poste,Contrat,Statut\n"+d.data.map(a=>`${a.matricule},${a.nom},${a.site_id||""},${a.poste},${a.type_contrat},${a.statut}`).join("\n"); const b=new Blob([csv],{type:"text/csv"}); const u=URL.createObjectURL(b); const a2=document.createElement("a"); a2.href=u; a2.download="agents.csv"; a2.click(); })} style={{padding:"7px 14px",border:"1px solid #ccc",borderRadius:6,fontSize:13,cursor:"pointer",background:"#fff"}}>Export CSV</button>
      </div>
      {error && <div style={{background:"#FCEBEB",color:"#791F1F",padding:"8px 12px",borderRadius:6,fontSize:13,marginBottom:12}}>{error}</div>}
      <div style={{background:"#fff",border:"1px solid #E0DDD5",borderRadius:10,overflow:"hidden"}}>
        <div style={{padding:"12px 16px",borderBottom:"1px solid #E0DDD5",fontSize:13,color:"#666"}}>{total} agents</div>
        <div style={{overflowX:"auto"}}>
          <table style={{width:"100%",borderCollapse:"collapse",fontSize:13}}>
            <thead><tr style={{background:"#F5F7FA"}}>
              <th style={{padding:"8px 12px",textAlign:"left",fontWeight:500,color:"#888",borderBottom:"1px solid #E0DDD5",width:120}}>Matricule</th>
              <th style={{padding:"8px 12px",textAlign:"left",fontWeight:500,color:"#888",borderBottom:"1px solid #E0DDD5"}}>Nom</th>
              <th style={{padding:"8px 12px",textAlign:"left",fontWeight:500,color:"#888",borderBottom:"1px solid #E0DDD5",width:120}}>Poste</th>
              <th style={{padding:"8px 12px",textAlign:"left",fontWeight:500,color:"#888",borderBottom:"1px solid #E0DDD5",width:80}}>Contrat</th>
              <th style={{padding:"8px 12px",textAlign:"left",fontWeight:500,color:"#888",borderBottom:"1px solid #E0DDD5",width:120}}>Téléphone</th>
              <th style={{padding:"8px 12px",textAlign:"left",fontWeight:500,color:"#888",borderBottom:"1px solid #E0DDD5",width:80}}>Statut</th>
              <th style={{padding:"8px 12px",textAlign:"left",fontWeight:500,color:"#888",borderBottom:"1px solid #E0DDD5",width:90}}>Actions</th>
            </tr></thead>
            <tbody>
              {loading ? <tr><td colSpan={7} style={{textAlign:"center",padding:32,color:"#888"}}>Chargement…</td></tr>
               : agents.map(a => (
                <tr key={a.id} style={{borderBottom:"1px solid #F0EDE8"}}>
                  <td style={{padding:"10px 12px",fontWeight:600,color:"#1B2D5B"}}>{a.matricule}</td>
                  <td style={{padding:"10px 12px",fontWeight:500}}>{a.nom}</td>
                  <td style={{padding:"10px 12px",fontSize:12,color:"#555"}}>{a.poste}</td>
                  <td style={{padding:"10px 12px"}}><span style={{background:"#E6EBF5",color:"#1B2D5B",borderRadius:99,padding:"2px 8px",fontSize:11,fontWeight:500}}>{a.type_contrat}</span></td>
                  <td style={{padding:"10px 12px",fontSize:12,color:"#555"}}>{a.telephone||"—"}</td>
                  <td style={{padding:"10px 12px"}}><span style={{background:statutBg[a.statut]||"#F1EFE8",color:statutColor[a.statut]||"#555",borderRadius:99,padding:"2px 8px",fontSize:11,fontWeight:500}}>{a.statut}</span></td>
                  <td style={{padding:"10px 12px"}}><div style={{display:"flex",gap:6}}>
                    <button onClick={()=>openEdit(a)} style={{padding:"4px 10px",border:"1px solid #ccc",borderRadius:5,fontSize:11,cursor:"pointer",background:"#fff"}}>Éditer</button>
                    <button onClick={()=>handleDelete(a.id)} style={{padding:"4px 10px",border:"1px solid #F7C1C1",borderRadius:5,fontSize:11,cursor:"pointer",background:"#FCEBEB",color:"#791F1F"}}>Suppr.</button>
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {showModal && (
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.4)",zIndex:100,display:"flex",alignItems:"flex-start",justifyContent:"center",paddingTop:40}}>
          <div style={{background:"#fff",borderRadius:12,width:560,maxHeight:"85vh",overflow:"auto",border:"1px solid #E0DDD5"}}>
            <div style={{padding:"16px 20px",borderBottom:"1px solid #E0DDD5",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <span style={{fontSize:15,fontWeight:600}}>{editAgent?"Modifier agent":"Nouvel agent"}</span>
              <button onClick={()=>setShowModal(false)} style={{border:"none",background:"none",cursor:"pointer",fontSize:20}}>×</button>
            </div>
            <div style={{padding:20}}>
              {error && <div style={{background:"#FCEBEB",color:"#791F1F",padding:"8px 12px",borderRadius:6,fontSize:13,marginBottom:12}}>{error}</div>}
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                {[["Matricule","matricule"],["Nom complet","nom"],["Téléphone","telephone"],["Agrément N°","agrement"]].map(([l,k])=>(
                  <div key={k}><label style={{display:"block",fontSize:12,color:"#666",marginBottom:3,fontWeight:500}}>{l}</label>
                  <input value={form[k]||""} onChange={e=>setForm({...form,[k]:e.target.value})} style={{width:"100%",padding:"7px 10px",border:"1px solid #ccc",borderRadius:6,fontSize:13,boxSizing:"border-box"}} /></div>
                ))}
                {[["Poste","poste",["Garde statique","Ronde","Contrôle accès","Garde rapprochée","Chef de poste"]],
                  ["Contrat","type_contrat",["CDI","CDD","Période d'essai","Apprentissage","Stage"]],
                  ["Vacation","vacation",["Jour","Nuit","Rotation"]],
                  ["Statut","statut",["Actif","Inactif","Suspendu","En congé"]]
                ].map(([l,k,opts])=>(
                  <div key={k}><label style={{display:"block",fontSize:12,color:"#666",marginBottom:3,fontWeight:500}}>{l}</label>
                  <select value={form[k]||""} onChange={e=>setForm({...form,[k]:e.target.value})} style={{width:"100%",padding:"7px 10px",border:"1px solid #ccc",borderRadius:6,fontSize:13,boxSizing:"border-box"}}>
                    {opts.map(o=><option key={o}>{o}</option>)}</select></div>
                ))}
                <div style={{gridColumn:"1/-1"}}><label style={{display:"block",fontSize:12,color:"#666",marginBottom:3,fontWeight:500}}>Observations</label>
                  <textarea value={form.observations||""} onChange={e=>setForm({...form,observations:e.target.value})} rows={3} style={{width:"100%",padding:"7px 10px",border:"1px solid #ccc",borderRadius:6,fontSize:13,boxSizing:"border-box",resize:"vertical"}} /></div>
              </div>
            </div>
            <div style={{padding:"12px 20px",borderTop:"1px solid #E0DDD5",display:"flex",justifyContent:"flex-end",gap:8}}>
              <button onClick={()=>setShowModal(false)} style={{padding:"7px 16px",border:"1px solid #ccc",borderRadius:6,fontSize:13,cursor:"pointer",background:"#fff"}}>Annuler</button>
              <button onClick={handleSave} disabled={saving} style={{padding:"7px 20px",background:"#1B2D5B",color:"#fff",border:"none",borderRadius:6,fontSize:13,cursor:"pointer"}}>
                {saving?"Enregistrement…":"Enregistrer"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}