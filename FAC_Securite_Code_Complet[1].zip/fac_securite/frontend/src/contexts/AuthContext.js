import React, { createContext, useContext, useState, useEffect } from "react";
import { api } from "../utils/api";
const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const token = localStorage.getItem("fac_token");
    if (token) {
      api.me().then(u => setUser(u)).catch(() => localStorage.clear()).finally(() => setLoading(false));
    } else { setLoading(false); }
  }, []);
  const login = async (email, password) => {
    const data = await api.login(email, password);
    localStorage.setItem("fac_token", data.token);
    setUser({ email: data.email, role: data.role, nom: data.nom });
    return data;
  };
  const logout = () => { localStorage.clear(); setUser(null); };
  return <AuthContext.Provider value={{ user, login, logout, loading }}>{children}</AuthContext.Provider>;
}
export const useAuth = () => useContext(AuthContext);