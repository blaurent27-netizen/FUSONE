const BASE = process.env.REACT_APP_BACKEND_URL || "http://localhost:8001";
function getToken() { return localStorage.getItem("fac_token"); }
async function req(method, path, body = null) {
  const headers = { "Content-Type": "application/json" };
  const token = getToken();
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const opts = { method, headers };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(`${BASE}${path}`, opts);
  if (res.status === 401) { localStorage.clear(); window.location.href = "/login"; }
  if (!res.ok) { const e = await res.json().catch(() => ({ detail: "Erreur" })); throw new Error(e.detail); }
  return res.json();
}
export const api = {
  login:(e,p)=>req("POST","/api/auth/login",{email:e,password:p}),
  me:()=>req("GET","/api/auth/me"),
  register:(d)=>req("POST","/api/auth/register",d),
  getAgents:(p={})=>req("GET",`/api/agents?${new URLSearchParams(p)}`),
  getAgent:(id)=>req("GET",`/api/agents/${id}`),
  createAgent:(d)=>req("POST","/api/agents",d),
  updateAgent:(id,d)=>req("PUT",`/api/agents/${id}`,d),
  deleteAgent:(id)=>req("DELETE",`/api/agents/${id}`),
  reaffecterAgent:(id,sid)=>req("POST",`/api/agents/${id}/reaffecter`,{site_id:sid}),
  getSites:(p={})=>req("GET",`/api/sites?${new URLSearchParams(p)}`),
  getSite:(id)=>req("GET",`/api/sites/${id}`),
  createSite:(d)=>req("POST","/api/sites",d),
  updateSite:(id,d)=>req("PUT",`/api/sites/${id}`,d),
  deleteSite:(id)=>req("DELETE",`/api/sites/${id}`),
  getPointages:(p={})=>req("GET",`/api/pointages?${new URLSearchParams(p)}`),
  createPointage:(d)=>req("POST","/api/pointages",d),
  getPointageStats:(date)=>req("GET",`/api/pointages/stats${date?`?date=${date}`:""}`),
  getPlanning:(p={})=>req("GET",`/api/planning?${new URLSearchParams(p)}`),
  createPlanning:(d)=>req("POST","/api/planning",d),
  bulkPlanning:(entries)=>req("PUT","/api/planning/bulk",{entries}),
  getStatsDashboard:()=>req("GET","/api/stats/dashboard"),
  getStatsSites:()=>req("GET","/api/stats/sites"),
  getStatsPresenceSem:()=>req("GET","/api/stats/presence_semaine"),
  getUsers:()=>req("GET","/api/users"),
  updateUser:(id,d)=>req("PUT",`/api/users/${id}`,d),
  deleteUser:(id)=>req("DELETE",`/api/users/${id}`),
};