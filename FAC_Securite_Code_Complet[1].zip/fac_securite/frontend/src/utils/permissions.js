export const ROLES_PERMISSIONS = {
  GAP:    ["agents","sites","pointages","stats","users","planning","dashboard"],
  RH:     ["agents","pointages","stats","planning","dashboard"],
  OPS:    ["sites","pointages","stats","planning","dashboard"],
  TERRAIN:["pointages"],
  CLIENT: ["stats"],
  COMPTA: ["stats","dashboard"],
};
export const ROLE_LABELS = {
  GAP:"Directeur GAP",RH:"Responsable RH",OPS:"Superviseur OPS",
  TERRAIN:"Agent Terrain",CLIENT:"Client",COMPTA:"Comptable"
};
export function can(role, module) {
  return (ROLES_PERMISSIONS[role]||[]).includes(module);
}