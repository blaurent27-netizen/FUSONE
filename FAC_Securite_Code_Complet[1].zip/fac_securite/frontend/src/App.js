import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Agents from "./pages/Agents";
import { can } from "./utils/permissions";

function PrivateRoute({ children, module }) {
  const { user, loading } = useAuth();
  if (loading) return <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"100vh",fontFamily:"Arial",color:"#666"}}>Chargement…</div>;
  if (!user) return <Navigate to="/login" />;
  if (module && !can(user.role, module)) return <div style={{padding:40,fontFamily:"Arial",color:"#791F1F"}}>Accès refusé — permission insuffisante.</div>;
  return <Layout>{children}</Layout>;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/agents" element={<PrivateRoute module="agents"><Agents /></PrivateRoute>} />
          <Route path="*" element={<Navigate to="/agents" />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}