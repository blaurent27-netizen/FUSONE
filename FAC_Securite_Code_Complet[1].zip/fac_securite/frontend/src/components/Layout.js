import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { can } from "../utils/permissions";

const NAV = [
  { path:"/dashboard", label:"Tableau de bord", icon:"dashboard",    mod:"dashboard" },
  { path:"/agents",    label:"Agents",           icon:"users",         mod:"agents"   },
  { path:"/sites",     label:"Sites",            icon:"building",      mod:"sites"    },
  { path:"/pointages", label:"Pointages",        icon:"fingerprint",   mod:"pointages"},
  { path:"/stats",     label:"Statistiques",     icon:"chart-bar",     mod:"stats"    },
  { path:"/planning",  label:"Planning",         icon:"calendar",      mod:"planning" },
  { path:"/users",     label:"Utilisateurs",     icon:"settings",      mod:"users"    },
];

export default function Layout({ children }) {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const initials = user?.nom?.split(" ").map(w=>w[0]).slice(0,2).join("").toUpperCase()||"??";

  return (
    <div style={{display:"flex",minHeight:"100vh",background:"#F5F7FA",fontFamily:"Arial,sans-serif"}}>
      <aside style={{width:220,background:"#1B2D5B",display:"flex",flexDirection:"column",flexShrink:0}}>
        <div style={{padding:"20px 16px 12px",borderBottom:"1px solid rgba(255,255,255,0.1)"}}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <div style={{width:32,height:32,background:"#C9A84C",borderRadius:6,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,color:"#1B2D5B"}}>🛡</div>
            <div><div style={{fontSize:15,fontWeight:600,color:"#fff"}}>FAC Sécurité</div><div style={{fontSize:10,color:"#C9A84C"}}>Gestion Intégrée</div></div>
          </div>
        </div>
        <div style={{padding:"12px 16px",borderBottom:"1px solid rgba(255,255,255,0.1)",display:"flex",alignItems:"center",gap:8}}>
          <div style={{width:32,height:32,borderRadius:"50%",background:"#C9A84C",display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,fontWeight:600,color:"#1B2D5B",flexShrink:0}}>{initials}</div>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontSize:12,fontWeight:600,color:"#fff",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{user?.nom}</div>
            <div style={{fontSize:10,color:"rgba(255,255,255,0.5)"}}>{user?.role}</div>
          </div>
        </div>
        <nav style={{padding:"8px 0",flex:1}}>
          {NAV.filter(n => can(user?.role, n.mod)).map(n => (
            <div key={n.path}
              onClick={() => nav(n.path)}
              style={{display:"flex",alignItems:"center",gap:10,padding:"9px 16px",cursor:"pointer",
                fontSize:13,color:loc.pathname===n.path?"#C9A84C":"rgba(255,255,255,0.65)",
                background:loc.pathname===n.path?"rgba(201,168,76,0.15)":"transparent",
                borderLeft:loc.pathname===n.path?"2px solid #C9A84C":"2px solid transparent"}}>
              <span>{n.label}</span>
            </div>
          ))}
        </nav>
        <div onClick={logout} style={{padding:"12px 16px",cursor:"pointer",fontSize:13,color:"rgba(255,255,255,0.5)",borderTop:"1px solid rgba(255,255,255,0.1)"}}>
          Déconnexion
        </div>
      </aside>
      <main style={{flex:1,display:"flex",flexDirection:"column",minWidth:0}}>
        {children}
      </main>
    </div>
  );
}