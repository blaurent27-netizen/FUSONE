"""
FAC SÉCURITÉ — Backend FastAPI complet
Version 1.0 | Sécurité Privée CI
"""
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, EmailStr, validator
from typing import Optional, List
from datetime import datetime, date, timedelta
from enum import Enum
import jwt
import hashlib
import os
from motor.motor_asyncio import AsyncIOMotorClient
from bson import ObjectId
import re

# ─── App ───────────────────────────────────────────────────────────
app = FastAPI(title="FAC Sécurité API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Config ────────────────────────────────────────────────────────
MONGO_URL   = os.getenv("MONGO_URL", "mongodb://localhost:27017/fac_securite")
JWT_SECRET  = os.getenv("JWT_SECRET", "fac-securite-secret-2024")
JWT_ALGO    = "HS256"
JWT_EXPIRE  = 24  # heures

# ─── DB ────────────────────────────────────────────────────────────
client = AsyncIOMotorClient(MONGO_URL)
db     = client.fac_securite

security = HTTPBearer()

# ─── Enums ─────────────────────────────────────────────────────────
class RoleEnum(str, Enum):
    GAP     = "GAP"
    RH      = "RH"
    OPS     = "OPS"
    TERRAIN = "TERRAIN"
    CLIENT  = "CLIENT"
    COMPTA  = "COMPTA"
    ADMIN   = "ADMIN"

class ContratEnum(str, Enum):
    CDI        = "CDI"
    CDD        = "CDD"
    ESSAI      = "Période d'essai"
    APPRENTI   = "Apprentissage"
    STAGE      = "Stage"

class StatutAgentEnum(str, Enum):
    ACTIF     = "Actif"
    INACTIF   = "Inactif"
    SUSPENDU  = "Suspendu"
    CONGE     = "En congé"

class TypePointageEnum(str, Enum):
    ENTREE  = "Entrée"
    SORTIE  = "Sortie"
    PAUSE   = "Pause"

class NiveauEnum(str, Enum):
    AGENT       = "Agent de sécurité"
    CHEF_EQUIPE = "Chef d'équipe"
    SUPERVISEUR = "Superviseur"
    CYNOPHILE   = "Cynophile"
    SSIAP1      = "SSIAP 1"
    SSIAP2      = "SSIAP 2"

class RisqueEnum(str, Enum):
    STANDARD = "Standard"
    ELEVE    = "Élevé"
    CRITIQUE = "Critique"

# ─── Helpers ───────────────────────────────────────────────────────
def hash_password(pwd: str) -> str:
    return hashlib.sha256(pwd.encode()).hexdigest()

def create_token(user_id: str, role: str) -> str:
    payload = {
        "sub": user_id,
        "role": role,
        "exp": datetime.utcnow() + timedelta(hours=JWT_EXPIRE)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGO)

def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGO])
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "Token expiré")
    except jwt.InvalidTokenError:
        raise HTTPException(401, "Token invalide")

def serialize(doc) -> dict:
    """Convertit ObjectId MongoDB en string"""
    if doc is None:
        return None
    doc["id"] = str(doc.pop("_id", ""))
    return doc

async def get_current_user(creds: HTTPAuthorizationCredentials = Depends(security)):
    payload = decode_token(creds.credentials)
    user = await db.users.find_one({"_id": ObjectId(payload["sub"])})
    if not user:
        raise HTTPException(401, "Utilisateur introuvable")
    return serialize(user)

def require_roles(*roles: RoleEnum):
    async def checker(user=Depends(get_current_user)):
        if user["role"] not in [r.value for r in roles]:
            raise HTTPException(403, f"Accès refusé. Rôles requis: {[r.value for r in roles]}")
        return user
    return checker

# ─── Modèles Pydantic ──────────────────────────────────────────────

class UserCreate(BaseModel):
    nom: str
    email: EmailStr
    password: str
    role: RoleEnum = RoleEnum.TERRAIN

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class AgentCreate(BaseModel):
    matricule: str
    nom: str
    prenom: str
    date_naissance: Optional[date] = None
    telephone: Optional[str] = None
    email: Optional[EmailStr] = None
    cni: Optional[str] = None
    site_id: Optional[str] = None
    site_nom: Optional[str] = None
    poste: Optional[str] = "Garde statique"
    vacation: Optional[str] = "Jour"
    contrat: ContratEnum = ContratEnum.CDI
    date_debut_contrat: Optional[date] = None
    date_fin_contrat: Optional[date] = None
    statut: StatutAgentEnum = StatutAgentEnum.ACTIF
    niveau: Optional[NiveauEnum] = NiveauEnum.AGENT
    agrement_numero: Optional[str] = None
    agrement_expiration: Optional[date] = None
    observations: Optional[str] = None

    @validator("telephone")
    def validate_phone(cls, v):
        if v and not re.match(r"^\+?[\d\s\-]{8,15}$", v):
            raise ValueError("Format téléphone invalide")
        return v

class AgentUpdate(AgentCreate):
    matricule: Optional[str] = None
    nom: Optional[str] = None

class SiteCreate(BaseModel):
    code: str
    nom_client: str
    nom_site: Optional[str] = None
    adresse: str
    region: Optional[str] = "Abidjan Nord"
    telephone_client: Optional[str] = None
    email_client: Optional[EmailStr] = None
    effectif_theorique: int = 1
    type_surveillance: Optional[str] = "Gardiennage"
    niveau_risque: RisqueEnum = RisqueEnum.STANDARD
    date_debut_contrat: Optional[date] = None
    date_fin_contrat: Optional[date] = None
    coordonnees_gps: Optional[dict] = None  # {"lat": 5.35, "lng": -4.01}
    rayon_pointage_metres: Optional[int] = 200
    actif: bool = True

class PointageCreate(BaseModel):
    agent_id: str
    site_id: str
    type_pointage: TypePointageEnum = TypePointageEnum.ENTREE
    heure_pointage: Optional[datetime] = None
    coordonnees_gps: Optional[dict] = None
    methode: Optional[str] = "Manuel"  # QR Code, NFC, GPS, Manuel
    commentaire: Optional[str] = None

class PlanningEntree(BaseModel):
    agent_id: str
    site_id: str
    date: date
    statut: str = "P"  # P=Présent, A=Absent, R=Repos, F=Formation, C=Congé
    vacation: Optional[str] = "Jour"

# ─── AUTH ──────────────────────────────────────────────────────────

@app.post("/api/auth/register", tags=["Auth"])
async def register(data: UserCreate):
    existing = await db.users.find_one({"email": data.email})
    if existing:
        raise HTTPException(400, "Email déjà utilisé")
    user_doc = {
        "nom": data.nom,
        "email": data.email,
        "password": hash_password(data.password),
        "role": data.role.value,
        "statut": "Actif",
        "created_at": datetime.utcnow(),
        "last_login": None,
    }
    result = await db.users.insert_one(user_doc)
    token = create_token(str(result.inserted_id), data.role.value)
    return {"token": token, "role": data.role.value, "nom": data.nom}

@app.post("/api/auth/login", tags=["Auth"])
async def login(data: UserLogin):
    user = await db.users.find_one({"email": data.email})
    if not user or user["password"] != hash_password(data.password):
        raise HTTPException(401, "Identifiants incorrects")
    await db.users.update_one({"_id": user["_id"]}, {"$set": {"last_login": datetime.utcnow()}})
    token = create_token(str(user["_id"]), user["role"])
    return {"token": token, "role": user["role"], "nom": user["nom"]}

@app.get("/api/auth/me", tags=["Auth"])
async def me(user=Depends(get_current_user)):
    user.pop("password", None)
    return user

# ─── AGENTS ────────────────────────────────────────────────────────

@app.get("/api/agents", tags=["Agents"])
async def list_agents(
    search: Optional[str] = None,
    site: Optional[str] = None,
    statut: Optional[str] = None,
    contrat: Optional[str] = None,
    skip: int = 0,
    limit: int = 50,
    user=Depends(require_roles(RoleEnum.GAP, RoleEnum.RH, RoleEnum.OPS))
):
    query = {}
    if search:
        query["$or"] = [
            {"nom": {"$regex": search, "$options": "i"}},
            {"prenom": {"$regex": search, "$options": "i"}},
            {"matricule": {"$regex": search, "$options": "i"}},
        ]
    if site:
        query["site_nom"] = {"$regex": site, "$options": "i"}
    if statut:
        query["statut"] = statut
    if contrat:
        query["contrat"] = contrat

    total = await db.agents.count_documents(query)
    cursor = db.agents.find(query).skip(skip).limit(limit).sort("nom", 1)
    agents = [serialize(a) async for a in cursor]
    return {"total": total, "agents": agents}

@app.post("/api/agents", status_code=201, tags=["Agents"])
async def create_agent(
    data: AgentCreate,
    user=Depends(require_roles(RoleEnum.GAP, RoleEnum.RH))
):
    existing = await db.agents.find_one({"matricule": data.matricule})
    if existing:
        raise HTTPException(400, f"Matricule {data.matricule} déjà existant")
    doc = data.dict()
    doc["created_by"] = user["id"]
    doc["created_at"] = datetime.utcnow()
    doc["updated_at"] = datetime.utcnow()
    # Convertir dates en string pour MongoDB
    for field in ["date_naissance","date_debut_contrat","date_fin_contrat","agrement_expiration"]:
        if doc.get(field):
            doc[field] = str(doc[field])
    result = await db.agents.insert_one(doc)
    doc["id"] = str(result.inserted_id)
    return doc

@app.get("/api/agents/{agent_id}", tags=["Agents"])
async def get_agent(agent_id: str, user=Depends(get_current_user)):
    try:
        agent = await db.agents.find_one({"_id": ObjectId(agent_id)})
    except:
        raise HTTPException(400, "ID invalide")
    if not agent:
        raise HTTPException(404, "Agent non trouvé")
    return serialize(agent)

@app.put("/api/agents/{agent_id}", tags=["Agents"])
async def update_agent(
    agent_id: str,
    data: AgentUpdate,
    user=Depends(require_roles(RoleEnum.GAP, RoleEnum.RH))
):
    try:
        oid = ObjectId(agent_id)
    except:
        raise HTTPException(400, "ID invalide")
    update_data = {k: str(v) if isinstance(v, date) else v
                   for k, v in data.dict(exclude_none=True).items()}
    update_data["updated_at"] = datetime.utcnow()
    result = await db.agents.update_one({"_id": oid}, {"$set": update_data})
    if result.matched_count == 0:
        raise HTTPException(404, "Agent non trouvé")
    return {"message": "Agent mis à jour"}

@app.delete("/api/agents/{agent_id}", tags=["Agents"])
async def delete_agent(
    agent_id: str,
    user=Depends(require_roles(RoleEnum.GAP, RoleEnum.RH))
):
    try:
        oid = ObjectId(agent_id)
    except:
        raise HTTPException(400, "ID invalide")
    result = await db.agents.delete_one({"_id": oid})
    if result.deleted_count == 0:
        raise HTTPException(404, "Agent non trouvé")
    return {"message": "Agent supprimé"}

@app.post("/api/agents/{agent_id}/reaffecter", tags=["Agents"])
async def reaffecter_agent(
    agent_id: str,
    site_id: str,
    site_nom: str,
    user=Depends(require_roles(RoleEnum.GAP, RoleEnum.OPS))
):
    try:
        oid = ObjectId(agent_id)
    except:
        raise HTTPException(400, "ID invalide")
    await db.agents.update_one(
        {"_id": oid},
        {"$set": {"site_id": site_id, "site_nom": site_nom, "updated_at": datetime.utcnow()}}
    )
    return {"message": "Agent réaffecté"}

# ─── SITES ─────────────────────────────────────────────────────────

@app.get("/api/sites", tags=["Sites"])
async def list_sites(
    search: Optional[str] = None,
    region: Optional[str] = None,
    actif: Optional[bool] = True,
    user=Depends(get_current_user)
):
    query = {}
    if actif is not None:
        query["actif"] = actif
    if search:
        query["$or"] = [
            {"nom_client": {"$regex": search, "$options": "i"}},
            {"nom_site": {"$regex": search, "$options": "i"}},
            {"code": {"$regex": search, "$options": "i"}},
        ]
    if region:
        query["region"] = region
    cursor = db.sites.find(query).sort("nom_client", 1)
    sites = [serialize(s) async for s in cursor]
    # Enrichir avec nb agents
    for s in sites:
        s["nb_agents"] = await db.agents.count_documents({"site_id": s["id"], "statut": "Actif"})
    return {"total": len(sites), "sites": sites}

@app.post("/api/sites", status_code=201, tags=["Sites"])
async def create_site(
    data: SiteCreate,
    user=Depends(require_roles(RoleEnum.GAP, RoleEnum.OPS))
):
    existing = await db.sites.find_one({"code": data.code})
    if existing:
        raise HTTPException(400, f"Code site {data.code} déjà existant")
    doc = data.dict()
    doc["created_by"] = user["id"]
    doc["created_at"] = datetime.utcnow()
    for field in ["date_debut_contrat","date_fin_contrat"]:
        if doc.get(field):
            doc[field] = str(doc[field])
    # Génération QR code ID (dans la vraie appli: générer image QR)
    doc["qr_code_id"] = f"QR-{data.code}-{datetime.utcnow().strftime('%Y%m%d')}"
    result = await db.sites.insert_one(doc)
    doc["id"] = str(result.inserted_id)
    return doc

@app.get("/api/sites/{site_id}", tags=["Sites"])
async def get_site(site_id: str, user=Depends(get_current_user)):
    try:
        site = await db.sites.find_one({"_id": ObjectId(site_id)})
    except:
        raise HTTPException(400, "ID invalide")
    if not site:
        raise HTTPException(404, "Site non trouvé")
    site = serialize(site)
    site["agents"] = [serialize(a) async for a in db.agents.find({"site_id": site_id})]
    return site

@app.put("/api/sites/{site_id}", tags=["Sites"])
async def update_site(
    site_id: str,
    data: SiteCreate,
    user=Depends(require_roles(RoleEnum.GAP, RoleEnum.OPS))
):
    try:
        oid = ObjectId(site_id)
    except:
        raise HTTPException(400, "ID invalide")
    update_data = {k: str(v) if isinstance(v, date) else v
                   for k, v in data.dict(exclude_none=True).items()}
    update_data["updated_at"] = datetime.utcnow()
    await db.sites.update_one({"_id": oid}, {"$set": update_data})
    return {"message": "Site mis à jour"}

@app.delete("/api/sites/{site_id}", tags=["Sites"])
async def delete_site(
    site_id: str,
    user=Depends(require_roles(RoleEnum.GAP))
):
    try:
        oid = ObjectId(site_id)
    except:
        raise HTTPException(400, "ID invalide")
    result = await db.sites.delete_one({"_id": oid})
    if result.deleted_count == 0:
        raise HTTPException(404, "Site non trouvé")
    return {"message": "Site supprimé"}

# ─── POINTAGES ─────────────────────────────────────────────────────

@app.get("/api/pointages", tags=["Pointages"])
async def list_pointages(
    date_debut: Optional[date] = None,
    date_fin: Optional[date] = None,
    site_id: Optional[str] = None,
    agent_id: Optional[str] = None,
    type_pointage: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    user=Depends(get_current_user)
):
    query = {}
    if date_debut or date_fin:
        query["heure_pointage"] = {}
        if date_debut:
            query["heure_pointage"]["$gte"] = datetime.combine(date_debut, datetime.min.time())
        if date_fin:
            query["heure_pointage"]["$lte"] = datetime.combine(date_fin, datetime.max.time())
    if site_id:
        query["site_id"] = site_id
    if agent_id:
        query["agent_id"] = agent_id
    if type_pointage:
        query["type_pointage"] = type_pointage

    total = await db.pointages.count_documents(query)
    cursor = db.pointages.find(query).skip(skip).limit(limit).sort("heure_pointage", -1)
    pointages = [serialize(p) async for p in cursor]
    return {"total": total, "pointages": pointages}

@app.post("/api/pointages", status_code=201, tags=["Pointages"])
async def create_pointage(
    data: PointageCreate,
    user=Depends(get_current_user)
):
    # Vérification agent
    try:
        agent = await db.agents.find_one({"_id": ObjectId(data.agent_id)})
    except:
        raise HTTPException(400, "Agent ID invalide")
    if not agent:
        raise HTTPException(404, "Agent non trouvé")

    # Vérification site
    try:
        site = await db.sites.find_one({"_id": ObjectId(data.site_id)})
    except:
        raise HTTPException(400, "Site ID invalide")
    if not site:
        raise HTTPException(404, "Site non trouvé")

    heure = data.heure_pointage or datetime.utcnow()

    # Calcul retard (si entrée et heure > 08:05)
    retard_minutes = 0
    if data.type_pointage == TypePointageEnum.ENTREE:
        heure_theorique = heure.replace(hour=8, minute=0, second=0)
        if heure > heure_theorique:
            retard_minutes = int((heure - heure_theorique).total_seconds() / 60)

    # Validation GPS (si coordonnées fournies)
    gps_valide = True
    if data.coordonnees_gps and site.get("coordonnees_gps") and site.get("rayon_pointage_metres"):
        import math
        lat1 = data.coordonnees_gps.get("lat", 0)
        lng1 = data.coordonnees_gps.get("lng", 0)
        lat2 = site["coordonnees_gps"].get("lat", 0)
        lng2 = site["coordonnees_gps"].get("lng", 0)
        # Distance approximative en mètres
        dist = math.sqrt((lat1-lat2)**2 + (lng1-lng2)**2) * 111320
        gps_valide = dist <= site["rayon_pointage_metres"]

    doc = {
        "agent_id": data.agent_id,
        "agent_nom": f"{agent.get('prenom','')} {agent['nom']}".strip(),
        "agent_matricule": agent.get("matricule", ""),
        "site_id": data.site_id,
        "site_nom": site.get("nom_client", ""),
        "type_pointage": data.type_pointage.value,
        "heure_pointage": heure,
        "retard_minutes": retard_minutes,
        "statut": "En retard" if retard_minutes > 5 else "À l'heure",
        "coordonnees_gps": data.coordonnees_gps,
        "gps_valide": gps_valide,
        "methode": data.methode,
        "commentaire": data.commentaire,
        "created_by": user["id"],
        "created_at": datetime.utcnow(),
    }
    result = await db.pointages.insert_one(doc)
    doc["id"] = str(result.inserted_id)
    return doc

@app.get("/api/pointages/stats/journalier", tags=["Pointages"])
async def stats_journalieres(
    date_cible: Optional[date] = None,
    user=Depends(get_current_user)
):
    d = date_cible or date.today()
    debut = datetime.combine(d, datetime.min.time())
    fin   = datetime.combine(d, datetime.max.time())

    total     = await db.pointages.count_documents({"heure_pointage": {"$gte": debut, "$lte": fin}})
    a_heure   = await db.pointages.count_documents({"heure_pointage": {"$gte": debut, "$lte": fin}, "statut": "À l'heure"})
    en_retard = await db.pointages.count_documents({"heure_pointage": {"$gte": debut, "$lte": fin}, "statut": "En retard"})
    total_agents = await db.agents.count_documents({"statut": "Actif"})

    return {
        "date": str(d),
        "total_pointages": total,
        "a_heure": a_heure,
        "en_retard": en_retard,
        "absents_estimes": max(0, total_agents - total),
        "taux_presence": round((total / total_agents * 100) if total_agents > 0 else 0, 1),
    }

# ─── PLANNING ──────────────────────────────────────────────────────

@app.get("/api/planning", tags=["Planning"])
async def get_planning(
    date_debut: date,
    date_fin: date,
    site_id: Optional[str] = None,
    user=Depends(get_current_user)
):
    query = {
        "date": {"$gte": str(date_debut), "$lte": str(date_fin)}
    }
    if site_id:
        query["site_id"] = site_id
    entries = [serialize(e) async for e in db.planning.find(query).sort("date", 1)]
    return {"total": len(entries), "planning": entries}

@app.post("/api/planning", status_code=201, tags=["Planning"])
async def set_planning(
    data: PlanningEntree,
    user=Depends(require_roles(RoleEnum.GAP, RoleEnum.RH, RoleEnum.OPS))
):
    # Upsert: remplace si existe déjà pour ce triplet (agent, site, date)
    doc = data.dict()
    doc["date"] = str(data.date)
    doc["updated_by"] = user["id"]
    doc["updated_at"] = datetime.utcnow()
    await db.planning.update_one(
        {"agent_id": data.agent_id, "site_id": data.site_id, "date": str(data.date)},
        {"$set": doc},
        upsert=True
    )
    return {"message": "Planning mis à jour"}

@app.post("/api/planning/bulk", tags=["Planning"])
async def set_planning_bulk(
    entries: List[PlanningEntree],
    user=Depends(require_roles(RoleEnum.GAP, RoleEnum.RH, RoleEnum.OPS))
):
    for entry in entries:
        doc = entry.dict()
        doc["date"] = str(entry.date)
        doc["updated_by"] = user["id"]
        doc["updated_at"] = datetime.utcnow()
        await db.planning.update_one(
            {"agent_id": entry.agent_id, "site_id": entry.site_id, "date": str(entry.date)},
            {"$set": doc},
            upsert=True
        )
    return {"message": f"{len(entries)} entrées mises à jour"}

# ─── STATISTIQUES ──────────────────────────────────────────────────

@app.get("/api/stats/dashboard", tags=["Statistiques"])
async def dashboard_stats(user=Depends(get_current_user)):
    total_agents   = await db.agents.count_documents({"statut": "Actif"})
    total_sites    = await db.sites.count_documents({"actif": True})
    today_debut    = datetime.combine(date.today(), datetime.min.time())
    today_fin      = datetime.combine(date.today(), datetime.max.time())
    pointages_jour = await db.pointages.count_documents({"heure_pointage": {"$gte": today_debut, "$lte": today_fin}})
    retards_jour   = await db.pointages.count_documents({"heure_pointage": {"$gte": today_debut, "$lte": today_fin}, "statut": "En retard"})
    absents        = max(0, total_agents - pointages_jour)

    # Présences 7 derniers jours
    presences_7j = []
    for i in range(6, -1, -1):
        d = date.today() - timedelta(days=i)
        db_d   = datetime.combine(d, datetime.min.time())
        df_d   = datetime.combine(d, datetime.max.time())
        count  = await db.pointages.count_documents({"heure_pointage": {"$gte": db_d, "$lte": df_d}})
        presences_7j.append({"date": str(d), "count": count})

    # Stats par site
    sites_cursor = db.sites.find({"actif": True})
    sites_stats  = []
    async for site in sites_cursor:
        s = serialize(site)
        nb_agents   = await db.agents.count_documents({"site_id": s["id"], "statut": "Actif"})
        nb_presents = await db.pointages.count_documents({"site_id": s["id"], "heure_pointage": {"$gte": today_debut, "$lte": today_fin}})
        sites_stats.append({
            "site": s.get("nom_client",""),
            "effectif_theorique": s.get("effectif_theorique", 0),
            "effectif_pratique": nb_agents,
            "presents_aujourd_hui": nb_presents,
            "manquants": max(0, nb_agents - nb_presents),
            "taux": round((nb_presents / nb_agents * 100) if nb_agents > 0 else 0, 1),
        })

    return {
        "total_agents": total_agents,
        "total_sites": total_sites,
        "pointages_jour": pointages_jour,
        "retards_jour": retards_jour,
        "absents_estimes": absents,
        "taux_presence": round((pointages_jour / total_agents * 100) if total_agents > 0 else 0, 1),
        "presences_7j": presences_7j,
        "stats_sites": sites_stats,
    }

@app.get("/api/stats/agents/{agent_id}/historique", tags=["Statistiques"])
async def agent_historique(
    agent_id: str,
    mois: Optional[int] = None,
    annee: Optional[int] = None,
    user=Depends(get_current_user)
):
    m = mois or date.today().month
    a = annee or date.today().year
    debut = datetime(a, m, 1)
    fin   = datetime(a, m, 28) + timedelta(days=4)
    fin   = fin.replace(day=1) - timedelta(days=1)
    fin   = datetime(a, fin.month, fin.day, 23, 59, 59)

    pointages = [serialize(p) async for p in db.pointages.find({"agent_id": agent_id, "heure_pointage": {"$gte": debut, "$lte": fin}})]
    total_jours = (fin.date() - debut.date()).days + 1
    jours_travailles = len(set(p["heure_pointage"].strftime("%Y-%m-%d") if isinstance(p.get("heure_pointage"), datetime) else str(p.get("heure_pointage",""))[:10] for p in pointages))
    retards = sum(1 for p in pointages if p.get("retard_minutes", 0) > 5)

    return {
        "agent_id": agent_id,
        "periode": f"{m}/{a}",
        "total_jours": total_jours,
        "jours_travailles": jours_travailles,
        "retards": retards,
        "taux_presence": round((jours_travailles / total_jours * 100) if total_jours > 0 else 0, 1),
        "pointages": pointages,
    }

# ─── UTILISATEURS ──────────────────────────────────────────────────

@app.get("/api/users", tags=["Utilisateurs"])
async def list_users(user=Depends(require_roles(RoleEnum.GAP, RoleEnum.ADMIN))):
    users_list = [serialize(u) async for u in db.users.find({}).sort("nom", 1)]
    for u in users_list:
        u.pop("password", None)
    return {"total": len(users_list), "users": users_list}

@app.put("/api/users/{user_id}/role", tags=["Utilisateurs"])
async def update_user_role(
    user_id: str,
    role: RoleEnum,
    user=Depends(require_roles(RoleEnum.GAP, RoleEnum.ADMIN))
):
    try:
        oid = ObjectId(user_id)
    except:
        raise HTTPException(400, "ID invalide")
    await db.users.update_one({"_id": oid}, {"$set": {"role": role.value}})
    return {"message": "Rôle mis à jour"}

@app.put("/api/users/{user_id}/statut", tags=["Utilisateurs"])
async def toggle_user_statut(
    user_id: str,
    statut: str,
    user=Depends(require_roles(RoleEnum.GAP, RoleEnum.ADMIN))
):
    try:
        oid = ObjectId(user_id)
    except:
        raise HTTPException(400, "ID invalide")
    await db.users.update_one({"_id": oid}, {"$set": {"statut": statut}})
    return {"message": "Statut mis à jour"}

# ─── HEALTH ────────────────────────────────────────────────────────

@app.get("/api/health", tags=["System"])
async def health():
    try:
        await db.command("ping")
        db_status = "connected"
    except:
        db_status = "disconnected"
    return {"status": "ok", "database": db_status, "version": "1.0.0"}

@app.on_event("startup")
async def startup():
    """Créer les index MongoDB au démarrage"""
    await db.agents.create_index("matricule", unique=True)
    await db.agents.create_index("site_id")
    await db.agents.create_index("statut")
    await db.sites.create_index("code", unique=True)
    await db.pointages.create_index([("heure_pointage", -1)])
    await db.pointages.create_index("agent_id")
    await db.pointages.create_index("site_id")
    await db.planning.create_index([("agent_id", 1), ("site_id", 1), ("date", 1)], unique=True)
    await db.users.create_index("email", unique=True)
    print("✅ FAC Sécurité API démarrée")
    print("📖 Docs : http://localhost:8001/docs")
